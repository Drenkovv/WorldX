import { motion } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import { Trophy, Star, Users, Gamepad2 } from 'lucide-react';

interface Game {
  id: number;
  title: string;
  image: string;
  rating: number;
  players: number;
  category: string;
}

interface Tournament {
  id: number;
  title: string;
  game: string;
  date: string;
  prize: string;
  participants: number;
  maxParticipants: number;
}

export default function Gaming() {
  const { t } = useTranslation();

  const featuredGames: Game[] = [
    {
      id: 1,
      title: "Cyberpunk 2077",
      image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80",
      rating: 4.5,
      players: 15000,
      category: "RPG"
    },
    {
      id: 2,
      title: "Neon Riders",
      image: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?auto=format&fit=crop&w=800&q=80",
      rating: 4.8,
      players: 8000,
      category: "Racing"
    },
    {
      id: 3,
      title: "Digital Warriors",
      image: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?auto=format&fit=crop&w=800&q=80",
      rating: 4.3,
      players: 12000,
      category: "Action"
    }
  ];

  const tournaments: Tournament[] = [
    {
      id: 1,
      title: "Cyber Championship 2025",
      game: "Cyberpunk 2077",
      date: "2025-03-15",
      prize: "$10,000",
      participants: 128,
      maxParticipants: 256
    },
    {
      id: 2,
      title: "Neon Speed Masters",
      game: "Neon Riders",
      date: "2025-03-20",
      prize: "$5,000",
      participants: 64,
      maxParticipants: 128
    }
  ];

  return (
    <div className="pt-20 min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-7xl mx-auto text-center"
        >
          <h1 className="text-5xl md:text-7xl font-bold mb-6 gradient-text neon-glow">
            Gaming Hub
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Join tournaments, discover new games, and connect with players worldwide
          </p>
        </motion.div>
      </section>

      {/* Featured Games */}
      <section className="px-4 py-16 bg-black/30">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <Gamepad2 className="w-8 h-8 mr-3 text-purple-400" />
            Featured Games
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredGames.map((game) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: 1.05 }}
                className="relative group"
              >
                <div className="relative overflow-hidden rounded-xl bg-black/50 backdrop-blur-sm border border-white/10">
                  <img
                    src={game.image}
                    alt={game.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{game.title}</h3>
                    <div className="flex items-center justify-between text-sm text-gray-400">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-400 mr-1" />
                        {game.rating}
                      </div>
                      <div className="flex items-center">
                        <Users className="w-4 h-4 text-blue-400 mr-1" />
                        {game.players.toLocaleString()}
                      </div>
                      <span className="px-2 py-1 rounded-full bg-purple-500/20 text-purple-400">
                        {game.category}
                      </span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Active Tournaments */}
      <section className="px-4 py-16">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 flex items-center">
            <Trophy className="w-8 h-8 mr-3 text-yellow-400" />
            Active Tournaments
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {tournaments.map((tournament) => (
              <motion.div
                key={tournament.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="relative"
              >
                <div className="p-6 rounded-xl bg-gradient-to-r from-purple-900/50 to-blue-900/50 backdrop-blur-sm border border-white/10">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-xl font-bold mb-1">{tournament.title}</h3>
                      <p className="text-gray-400">{tournament.game}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-yellow-400 font-bold">{tournament.prize}</div>
                      <div className="text-sm text-gray-400">Prize Pool</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <div className="flex items-center text-gray-400">
                      <Users className="w-4 h-4 mr-1" />
                      {tournament.participants}/{tournament.maxParticipants}
                    </div>
                    <div className="text-gray-400">
                      {new Date(tournament.date).toLocaleDateString()}
                    </div>
                    <button className="px-4 py-2 rounded-full bg-purple-500 hover:bg-purple-600 transition">
                      Join Tournament
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}